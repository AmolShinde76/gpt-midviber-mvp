from openai import OpenAI

# Set your API key
client = OpenAI(api_key = "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")




def upload_file():
    file = client.files.create(
    file=open("", "rb"),
    purpose="assistants"  
    )
    print("File ID:", file.id)



def fileStatus():
    # Retrieve file details
    file_status = client.files.retrieve("file-HKVYN4qp29bB6nCKh9fab5")

    print("File ID:", file_status.id)
    print("Filename:", file_status.filename)
    print("Purpose:", file_status.purpose)
    print("Status:", file_status.status)   # usually "uploaded" or "processed"
    print("Bytes:", file_status.bytes)

fileStatus()