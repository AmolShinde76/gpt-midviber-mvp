from openai import OpenAI

# Set your API key
client = OpenAI(api_key = "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")


response = client.chat.completions.create(
    model="gpt-4o-mini",  # or "gpt-4o" if you want GPT-4
    messages=[
        {"role": "user", "content": "What is the capital of France?"}
    ]
)

print(f"tokens = {response.usage.total_tokens}")
print(f"Answer = {response.choices[0].message.content}")
