from openai import OpenAI
import time

# 🔹 Initialize client
client = OpenAI(api_key="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")

# Use your existing file ID here
file_id = "file-HKVYN4qp29bB6nCKh9fab5"



# Create Assistant (use file_search instead of retrieval)
assistant = client.beta.assistants.create(
    model="gpt-4o-mini",
    instructions="Answer questions based only on the attached PDF.",
    tools=[{"type": "file_search"}]
)

# Create a thread
thread = client.beta.threads.create()
def ask(question):
    # Add user question + attach file
    client.beta.threads.messages.create(
        thread_id=thread.id,
        role="user",
        content=question,
        attachments=[{"file_id": file_id, "tools": [{"type": "file_search"}]}]
    )

    # Run assistant
    run = client.beta.threads.runs.create(thread_id=thread.id, assistant_id=assistant.id)

    # Wait until it completes
    while True:
        status = client.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)
        if status.status == "completed":
            break
        time.sleep(1)

    # Get answer
    messages = client.beta.threads.messages.list(thread_id=thread.id)
    answer = messages.data[0].content[0].text.value

    # Token usage
    usage = status.usage
    total_tokens = usage.total_tokens if usage else "N/A"

    print("Answer:", answer)
    print("Total tokens used:", total_tokens)

# Example usage
ask("explain Composition")